<?php ob_start();


session_start();


include("db.php");
include("functions.php");




 ?>